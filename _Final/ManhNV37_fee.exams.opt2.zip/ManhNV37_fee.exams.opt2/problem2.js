const data = [
	{
		image: "./images/product-1.png",
		description: "MASS AST <br> Color: black, Material: metal",
		quantity: 1,
		price: 120,
		discount: 25
	},
	{
		image: "./images/product-2.png",
		description: "MASS AST <br> Color: black, Material: metal",
		quantity: 1,
		price: 7,
		discount: 0
	},
	{
		image: "./images/product-3.png",
		description: "MASS AST <br> Color: black, Material: metal",
		quantity: 1,
		price: 120,
		discount: 25
	}
];

const table = document.querySelector("#table tbody");
const totalPriceElement = document.getElementById("total_price");
const totalDiscountElement = document.getElementById("total_discount");
const totalTaxElement = document.getElementById("total_tax");

let totalPrice = 0;
let totalDiscount = 0;
let totalTax = 0;

// first render
render();

function render() {
	// reset
	table.innerHTML = "";
	totalPrice = totalDiscount = totalTax = 0;

	data.forEach((product, index) => {
		const quantity = product.quantity;
		const price = product.price;
		const discount = product.discount;

		const tax = Math.ceil(quantity * price * 0.125);
		const total = quantity * price - discount + tax;

		totalPrice += total;
		totalDiscount += discount;
		totalTax += tax;

		const tr = document.createElement("tr");

		tr.innerHTML = `
			<td>
				<img src="${product.image}" alt="camera">
			</td>
			<td>
				<p>
					${product.description}
				</p>
			</td>
			<td>
				<div class="buttons-container">
					<input type="number" value="${product.quantity}" min="1" title="quantity" class="quantity-input">
					<button class="btn decrease-btn">-</button>
					<button class="btn increase-btn">+</button>
					<button class="btn remove-btn">x</button>
				</div>
			</td>
			<td>$${product.price.toFixed(2)}</td>
			<td>${discount !== 0? "$" + discount.toFixed(2): "--"}</td>
			<td>$${tax.toFixed(2)}</td>
			<td>$${total.toFixed(2)}</td>
		`;

		// add events
		const quantityInput = tr.querySelector(".quantity-input");
		const decreaseBtn = tr.querySelector(".buttons-container .decrease-btn")
		const increaseBtn = tr.querySelector(".buttons-container .increase-btn")
		const removeBtn = tr.querySelector(".buttons-container .remove-btn")

		quantityInput.onchange = function() {
			if(quantityInput.value < 1) {
				quantityInput.value = 1;
			}

			// update data
			data[index].quantity = quantityInput.value;

			// re-render
			render();
		}

		decreaseBtn.onclick = function() {
			quantityInput.value--;

			if(quantityInput.value < 1) {
				quantityInput.value = 1;
			}

			// update data
			data[index].quantity = quantityInput.value;

			// re-render
			render();
		}
		increaseBtn.onclick = function() {
			quantityInput.value++;

			// update data
			data[index].quantity = quantityInput.value;

			// re-render
			render();
		}
		removeBtn.onclick = function() {
			// remove from DOM
			tr.remove();

			// update total
			totalPrice -= total;
			totalDiscount -= discount;
			totalTax -= tax;

			data.splice(index, 1); // remove the row from data

			// re-render
			render();
		}

		// add row to table
		table.appendChild(tr);
	});

	// total
	totalPriceElement.innerHTML = "$" + totalPrice.toFixed(2);
	totalDiscountElement.innerHTML = "$" + totalDiscount.toFixed(2);
	totalTaxElement.innerHTML = "$" + totalTax.toFixed(2);
}