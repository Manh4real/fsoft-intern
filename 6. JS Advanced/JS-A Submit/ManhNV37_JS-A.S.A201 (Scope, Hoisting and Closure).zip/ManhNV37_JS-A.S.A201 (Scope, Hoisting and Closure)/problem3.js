var a = 1;

function b() {
	a = 10;
	return;

	function a() { }
}

b();

console.log(a); 
// 1 - Do hoisting, trong function "b", ban đầu biến "a" là một function và tồn tại trong
// function scope ("b()" local environment)
// (Vì vậy, biến "a" ở global không bị ảnh hưởng trong trường hợp này)
// Sau đó, "a" (trong "b" function) được gán bằng 10.