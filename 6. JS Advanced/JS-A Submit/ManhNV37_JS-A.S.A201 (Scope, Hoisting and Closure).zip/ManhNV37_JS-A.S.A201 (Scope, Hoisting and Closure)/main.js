var nodes = document.getElementsByTagName('button');

for (let i = 0; i < nodes.length; i++) {
	nodes[i].addEventListener('click', function() {
		console.log('You clicked element #' + i);
	});
}

/*
"var" statement khai báo biến ở function scope hoặc global scope
Vì vậy đoạn code "var i = 0" làm cho biến "i" có thể được access toàn cục (trong trường hợp này)
=> Khi "for" loop kết thúc, giá trị của "i" bằng 4 (đã thay đổi trong từng vòng lặp)

Fix: sử dụng "let" statement. Mỗi vòng lặp tạo ra một scope mới, do đó "addEventListener" callback
có thể access "i" một cách chính xác hơn.
*/