function test() {
	console.log(a);
	console.log(foo());

	var a = 1;

	function foo() {
		return 2;
	}
}

test(); // undefined 2

// Do hoisting nên biến "a" đã được khởi tạo nhưng chưa được gán giá trị trước khi sử dụng ở console.log
// "foo" function lexical scope là "test" function local environment.